package com.example.eventtracker_zachary_kosto;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    private TextView textPermissionStatus;
    private Button buttonRequest, buttonSend;

    // Modern permission launcher
    private final ActivityResultLauncher<String> requestSmsPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                updateStatus();
                if (isGranted) {
                    Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        textPermissionStatus = findViewById(R.id.textPermissionStatus);
        buttonRequest = findViewById(R.id.buttonRequestPermission);
        buttonSend = findViewById(R.id.buttonSendTest);

        updateStatus();

        buttonRequest.setOnClickListener(v -> checkOrRequest());

        buttonSend.setOnClickListener(v -> {
            if (hasSmsPermission()) {
                sendTestAlert();
            } else {
                Toast.makeText(this, "Permission required before sending alerts", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    private void checkOrRequest() {
        if (hasSmsPermission()) {
            Toast.makeText(this, "Permission already granted", Toast.LENGTH_SHORT).show();
            updateStatus();
        } else {
            requestSmsPermission.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void updateStatus() {
        textPermissionStatus.setText(
                "Permission status: " + (hasSmsPermission() ? "GRANTED" : "NOT GRANTED"));
    }

    private void sendTestAlert() {
        // If the device/emulator has no telephony, just simulate.
        PackageManager pm = getPackageManager();
        boolean hasTelephony = pm.hasSystemFeature(PackageManager.FEATURE_TELEPHONY);

        String testNumber = "5551234"; // placeholder
        String msg = "EventTracker: You have an upcoming event! (test)";

        if (!hasTelephony) {
            // Simulate only
            Toast.makeText(this, "Simulated SMS → " + msg, Toast.LENGTH_LONG).show();
            return;
        }

        try {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(testNumber, null, msg, null, null);
            Toast.makeText(this, "SMS sent to " + testNumber, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS (simulating instead)", Toast.LENGTH_SHORT).show();
        }
    }

    // Optional helper to open from anywhere
    public static void open(Context ctx) {
        Intent i = new Intent(ctx, SmsPermissionActivity.class);
        ctx.startActivity(i);
    }
}