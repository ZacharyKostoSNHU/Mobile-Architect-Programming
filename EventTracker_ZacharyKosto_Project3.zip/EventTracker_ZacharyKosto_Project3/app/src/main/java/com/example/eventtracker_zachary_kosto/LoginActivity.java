package com.example.eventtracker_zachary_kosto;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button   buttonLogin;
    private Button   buttonCreateAccount;

    private DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // uses activity_login.xml

        db = new DBHelper(this);

        usernameEditText   = findViewById(R.id.usernameEditText);
        passwordEditText   = findViewById(R.id.passwordEditText);
        buttonLogin        = findViewById(R.id.buttonLogin);
        buttonCreateAccount= findViewById(R.id.buttonCreateAccount);

        // Log in existing user
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String user = text(usernameEditText);
                String pass = text(passwordEditText);

                if (TextUtils.isEmpty(user) || TextUtils.isEmpty(pass)) {
                    Toast.makeText(LoginActivity.this, "Enter username and password", Toast.LENGTH_SHORT).show();
                    return;
                }

                // <-- This is the correct DBHelper method name
                if (db.checkLogin(user, pass)) {
                    Toast.makeText(LoginActivity.this, "Welcome, " + user + "!", Toast.LENGTH_SHORT).show();
                    goToEvents();
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Create new account, then continue to Events
        buttonCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String user = text(usernameEditText);
                String pass = text(passwordEditText);

                if (TextUtils.isEmpty(user) || TextUtils.isEmpty(pass)) {
                    Toast.makeText(LoginActivity.this, "Choose a username and password", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean created = db.createUser(user, pass);
                if (created) {
                    Toast.makeText(LoginActivity.this, "Account created. You're logged in.", Toast.LENGTH_SHORT).show();
                    goToEvents();
                } else {
                    Toast.makeText(LoginActivity.this, "Username already exists", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private String text(EditText e) {
        return e.getText() == null ? "" : e.getText().toString().trim();
    }

    private void goToEvents() {
        Intent i = new Intent(LoginActivity.this, EventsActivity.class);
        startActivity(i);
    }
}