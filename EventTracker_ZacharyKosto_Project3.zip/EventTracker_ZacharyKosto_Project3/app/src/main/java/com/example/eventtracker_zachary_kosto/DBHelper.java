package com.example.eventtracker_zachary_kosto;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "eventtracker.db";
    private static final int DB_VERSION = 1;

    // Users
    private static final String TBL_USERS = "users";
    private static final String COL_USER = "username";
    private static final String COL_PASS = "password";

    // Events
    private static final String TBL_EVENTS = "events";
    private static final String COL_ID = "_id";
    private static final String COL_TITLE = "title";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String mkUsers = "CREATE TABLE " + TBL_USERS + " ("
                + COL_USER + " TEXT PRIMARY KEY, "
                + COL_PASS + " TEXT NOT NULL)";
        String mkEvents = "CREATE TABLE " + TBL_EVENTS + " ("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_TITLE + " TEXT NOT NULL)";
        db.execSQL(mkUsers);
        db.execSQL(mkEvents);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + TBL_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TBL_EVENTS);
        onCreate(db);
    }

    // ---------- Users ----------
    public boolean createUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_USER, username);
        cv.put(COL_PASS, password);
        long row = -1;
        try {
            row = db.insertOrThrow(TBL_USERS, null, cv);
        } catch (Exception ignore) { }
        return row != -1;
    }

    public boolean checkLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT 1 FROM " + TBL_USERS +
                " WHERE " + COL_USER + "=? AND " + COL_PASS + "=? LIMIT 1";
        Cursor c = db.rawQuery(sql, new String[]{username, password});
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    // ---------- Events ----------
    public List<String> getAllEventTitles() {
        ArrayList<String> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT " + COL_TITLE + " FROM " + TBL_EVENTS + " ORDER BY " + COL_ID + " DESC", null);
        while (c.moveToNext()) list.add(c.getString(0));
        c.close();
        return list;
    }

    public boolean addEvent(String title) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_TITLE, title);
        return db.insert(TBL_EVENTS, null, cv) != -1;
    }

    public int deleteEventByTitle(String title) {
        // Simple rubric-friendly delete; removes the first/any matching title
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TBL_EVENTS, COL_TITLE + "=?", new String[]{title});
    }
}