package com.example.eventtracker_zachary_kosto;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class EventsActivity extends AppCompatActivity {

    private DBHelper db;
    private EditText eventInput;
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        db = new DBHelper(this);

        eventInput   = findViewById(R.id.eventInput);
        listView     = findViewById(R.id.eventsListView);
        Button addBtn      = findViewById(R.id.addEventButton);
        Button deleteBtn   = findViewById(R.id.deleteEventButton);
        Button smsBtn      = findViewById(R.id.buttonSmsAlerts); // <-- NEW: SMS button

        // single-select so we can delete the selected row
        listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        // Load from DB -> ListView
        List<String> fromDb = db.getAllEventTitles();
        data = new ArrayList<>(fromDb);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_single_choice, data);
        listView.setAdapter(adapter);

        addBtn.setOnClickListener(v -> addEvent());
        deleteBtn.setOnClickListener(v -> deleteSelected());

        // NEW: open the SMS permission screen
        smsBtn.setOnClickListener(v -> SmsPermissionActivity.open(EventsActivity.this));
    }

    private void addEvent() {
        String title = eventInput.getText().toString().trim();
        if (TextUtils.isEmpty(title)) {
            Toast.makeText(this, "Enter an event name", Toast.LENGTH_SHORT).show();
            return;
        }
        if (db.addEvent(title)) {
            data.add(0, title);               // keep newest on top like our query
            adapter.notifyDataSetChanged();
            eventInput.setText("");
        } else {
            Toast.makeText(this, "Could not add event", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteSelected() {
        int pos = listView.getCheckedItemPosition();
        if (pos == ListView.INVALID_POSITION) {
            Toast.makeText(this, "Select a row to delete", Toast.LENGTH_SHORT).show();
            return;
        }
        String title = data.get(pos);
        int rows = db.deleteEventByTitle(title);
        if (rows > 0) {
            data.remove(pos);
            adapter.notifyDataSetChanged();
            listView.clearChoices();
        } else {
            Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
        }
    }
}