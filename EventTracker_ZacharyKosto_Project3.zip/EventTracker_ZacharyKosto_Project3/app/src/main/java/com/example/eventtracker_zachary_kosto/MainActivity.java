package com.example.eventtracker_zachary_kosto;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.text.Editable;
import android.text.TextWatcher;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText nameText;
    private TextView textGreeting;
    private Button buttonSayHello;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Link UI components to IDs from activity_main.xml
        nameText = findViewById(R.id.nameText);
        textGreeting = findViewById(R.id.textGreeting);
        buttonSayHello = findViewById(R.id.buttonSayHello);

        // Button starts disabled (reinforces android:enabled="false" in XML)
        buttonSayHello.setEnabled(false);

        // Add a listener so the button enables/disables based on input
        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Enable button only if text field is not empty
                buttonSayHello.setEnabled(s != null && s.toString().trim().length() > 0);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    // Function called when buttonSayHello is clicked
    public void SayHello(View view) {
        if (nameText == null || textGreeting == null) {
            return; // safety guard
        }

        String name = nameText.getText() == null ? "" : nameText.getText().toString().trim();
        if (name.isEmpty()) {
            return; // do nothing if field is empty
        }

        // Display the greeting
        textGreeting.setText("Hello " + name);
    }
}